// Lightweight auth + active-customer storage.
//
// Tokens and the active X-Customer codename live in localStorage. In a future
// iteration these move to HttpOnly cookies issued by the backend; for now this
// keeps the foundation moving without inventing infra.

const TOKEN_KEY = 'detectmap.token';
const CUSTOMER_KEY = 'detectmap.customer';

export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearToken(): void {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(CUSTOMER_KEY);
}

export function getActiveCustomer(): string | null {
  if (typeof window === 'undefined') return null;
  return localStorage.getItem(CUSTOMER_KEY);
}

export function setActiveCustomer(codename: string | null): void {
  if (codename) localStorage.setItem(CUSTOMER_KEY, codename);
  else localStorage.removeItem(CUSTOMER_KEY);
}

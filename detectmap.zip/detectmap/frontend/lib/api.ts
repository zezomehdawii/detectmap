import axios from 'axios';
import { clearToken, getActiveCustomer, getToken } from './auth';

const baseURL =
  process.env.NEXT_PUBLIC_API_BASE ?? 'http://localhost:8000';

export const api = axios.create({
  baseURL,
  timeout: 30000,
});

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) {
    config.headers = config.headers ?? {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  const customer = getActiveCustomer();
  if (customer) {
    config.headers = config.headers ?? {};
    config.headers['X-Customer'] = customer;
  }
  return config;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err?.response?.status === 401 && typeof window !== 'undefined') {
      clearToken();
      // Avoid a redirect loop if we're already on /login.
      if (!window.location.pathname.startsWith('/login')) {
        window.location.href = '/login';
      }
    }
    return Promise.reject(err);
  },
);

// ---- typed endpoints ----
export interface MeResponse {
  user_id: string;
  email: string;
  role: string;
  customer_codename: string | null;
  customer_name: string | null;
  mssp_org_id: string | null;
}

export interface CustomerOut {
  id: string;
  codename: string;
  name: string;
  sector: string | null;
  status: string;
  schema_name: string;
}

export async function login(email: string, password: string): Promise<string> {
  const { data } = await api.post<{ access_token: string }>('/auth/login', {
    email,
    password,
  });
  return data.access_token;
}

export async function fetchMe(): Promise<MeResponse> {
  const { data } = await api.get<MeResponse>('/auth/me');
  return data;
}

export async function listCustomers(): Promise<CustomerOut[]> {
  const { data } = await api.get<CustomerOut[]>('/customers');
  return data;
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  Alert,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  CircularProgress,
  LinearProgress,
  Stack,
  Typography,
} from '@mui/material';
import ArrowOutwardRoundedIcon from '@mui/icons-material/ArrowOutwardRounded';
import SwapHorizRoundedIcon from '@mui/icons-material/SwapHorizRounded';
import TrendingUpRoundedIcon from '@mui/icons-material/TrendingUpRounded';

import { getActiveCustomer, getToken } from '@/lib/auth';
import { fetchMe, MeResponse } from '@/lib/api';
import { coverage, gradients } from '../theme';

const MSSP_ROLES = new Set([
  'mssp_admin',
  'mssp_analyst',
  'mssp_readonly',
  'product_super_admin',
]);

// Placeholder distribution for Phase 1. Phase 4 wires real coverage data.
const PLACEHOLDER_BREAKDOWN = [
  { label: 'Strong', value: 0, color: coverage.green },
  { label: 'Partial', value: 0, color: coverage.amber },
  { label: 'Gap', value: 0, color: coverage.red },
  { label: 'N/A', value: 0, color: coverage.blue },
  { label: 'Out of scope', value: 0, color: coverage.grey },
];

export default function DashboardPage() {
  const router = useRouter();
  const [me, setMe] = useState<MeResponse | null>(null);
  const [activeCustomer, setActive] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!getToken()) {
      router.replace('/login');
      return;
    }
    let cancelled = false;
    fetchMe()
      .then((data) => {
        if (cancelled) return;
        setMe(data);
        setActive(getActiveCustomer());
      })
      .catch(() => {
        if (!cancelled) router.replace('/login');
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [router]);

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 8 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!me) return null;

  const isMssp = MSSP_ROLES.has(me.role);
  const needsCustomerSelection = isMssp && !activeCustomer;

  if (needsCustomerSelection) {
    return <SelectCustomerEmptyState />;
  }

  const customerLabel = activeCustomer ?? me.customer_codename ?? '—';

  return (
    <Stack spacing={3}>
      <PostureHero customerCodename={customerLabel} />
      <Box
        sx={{
          display: 'grid',
          gap: 3,
          gridTemplateColumns: { xs: '1fr', md: '2fr 1fr' },
        }}
      >
        <CoverageBreakdownCard />
        <TopGapsCard />
      </Box>
      <Alert severity="info" variant="outlined" sx={{ borderRadius: 3 }}>
        Coverage analytics will populate once the ATT&amp;CK catalog ingest
        (Phase 2) and detection sync (Phase 3) complete for this customer.
      </Alert>
    </Stack>
  );
}

function PostureHero({ customerCodename }: { customerCodename: string }) {
  return (
    <Card
      sx={{
        position: 'relative',
        overflow: 'hidden',
        background: gradients.cta,
        color: 'common.white',
        border: 'none',
      }}
    >
      <Box
        aria-hidden
        sx={{
          position: 'absolute',
          inset: 0,
          background:
            'radial-gradient(circle at 85% 15%, rgba(255,255,255,0.25), transparent 55%)',
          pointerEvents: 'none',
        }}
      />
      <CardContent sx={{ position: 'relative', p: { xs: 3, md: 4 } }}>
        <Stack
          direction={{ xs: 'column', md: 'row' }}
          spacing={3}
          alignItems={{ md: 'center' }}
          justifyContent="space-between"
        >
          <Box>
            <Typography
              variant="overline"
              sx={{ opacity: 0.85, letterSpacing: 1.5 }}
            >
              Detection Posture · {customerCodename}
            </Typography>
            <Typography variant="h3" sx={{ fontWeight: 800, mt: 1 }}>
              —
            </Typography>
            <Typography variant="body1" sx={{ opacity: 0.9, mt: 1, maxWidth: 520 }}>
              Posture grade derives from analytical breadth (A-B) × depth (A-D)
              once detections are mapped to ATT&amp;CK techniques in scope.
            </Typography>
          </Box>
          <Stack spacing={1.5} direction={{ xs: 'row', md: 'column' }}>
            <HeroMetric label="Breadth (A-B)" value="—" />
            <HeroMetric label="Depth (A-D)" value="—" />
            <HeroMetric label="Techniques in scope" value="—" />
          </Stack>
        </Stack>
      </CardContent>
    </Card>
  );
}

function HeroMetric({ label, value }: { label: string; value: string }) {
  return (
    <Box
      sx={{
        bgcolor: 'rgba(255,255,255,0.14)',
        border: '1px solid rgba(255,255,255,0.22)',
        borderRadius: 2,
        px: 2,
        py: 1.2,
        minWidth: 160,
      }}
    >
      <Typography variant="caption" sx={{ opacity: 0.85 }}>
        {label}
      </Typography>
      <Typography variant="h6" sx={{ fontWeight: 700, lineHeight: 1.2 }}>
        {value}
      </Typography>
    </Box>
  );
}

function CoverageBreakdownCard() {
  const total = PLACEHOLDER_BREAKDOWN.reduce((sum, b) => sum + b.value, 0);

  return (
    <Card>
      <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          mb={2}
        >
          <Box>
            <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
              Coverage breakdown
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Distribution of in-scope techniques by detection state.
            </Typography>
          </Box>
          <Chip
            icon={<TrendingUpRoundedIcon sx={{ fontSize: 16 }} />}
            label="Phase 4"
            size="small"
            sx={{ fontWeight: 600 }}
          />
        </Stack>
        <Stack spacing={2}>
          {PLACEHOLDER_BREAKDOWN.map((item) => (
            <Box key={item.label}>
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="baseline"
                mb={0.5}
              >
                <Stack direction="row" spacing={1} alignItems="center">
                  <Box
                    sx={{
                      width: 10,
                      height: 10,
                      borderRadius: '3px',
                      bgcolor: item.color,
                    }}
                  />
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>
                    {item.label}
                  </Typography>
                </Stack>
                <Typography variant="caption" color="text.secondary">
                  {item.value} techniques
                </Typography>
              </Stack>
              <LinearProgress
                variant="determinate"
                value={total === 0 ? 0 : (item.value / total) * 100}
                sx={{
                  height: 8,
                  borderRadius: 4,
                  bgcolor: 'rgba(15,18,35,0.06)',
                  '& .MuiLinearProgress-bar': {
                    bgcolor: item.color,
                    borderRadius: 4,
                  },
                }}
              />
            </Box>
          ))}
        </Stack>
      </CardContent>
    </Card>
  );
}

function TopGapsCard() {
  return (
    <Card>
      <CardContent sx={{ p: { xs: 2.5, md: 3 } }}>
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          mb={2}
        >
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
            Top gaps by APT prevalence
          </Typography>
          <Chip label="Phase 5" size="small" sx={{ fontWeight: 600 }} />
        </Stack>
        <Stack
          spacing={1.5}
          sx={{
            color: 'text.secondary',
          }}
        >
          {[1, 2, 3, 4, 5].map((i) => (
            <Box
              key={i}
              sx={{
                p: 1.5,
                borderRadius: 2,
                bgcolor: 'rgba(79,70,229,0.04)',
                border: '1px dashed rgba(79,70,229,0.18)',
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Typography
                  variant="body2"
                  sx={{
                    fontFamily: 'var(--font-mono, JetBrains Mono, monospace)',
                    fontWeight: 600,
                    color: 'text.primary',
                  }}
                >
                  T—.—
                </Typography>
                <Typography variant="caption">— APT groups</Typography>
              </Stack>
              <Typography variant="caption">
                Technique gap ranked by adversary prevalence will appear here.
              </Typography>
            </Box>
          ))}
        </Stack>
      </CardContent>
    </Card>
  );
}

function SelectCustomerEmptyState() {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '60vh',
      }}
    >
      <Card sx={{ maxWidth: 520, textAlign: 'center' }}>
        <CardContent sx={{ p: { xs: 4, md: 5 } }}>
          <Box
            sx={{
              width: 64,
              height: 64,
              mx: 'auto',
              mb: 2.5,
              borderRadius: '50%',
              background: gradients.cta,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'common.white',
            }}
          >
            <SwapHorizRoundedIcon sx={{ fontSize: 32 }} />
          </Box>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 1 }}>
            Select a customer
          </Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
            Use the customer switcher in the top bar to load a customer&apos;s
            detection posture, coverage matrix, and reports. Each customer
            lives in an isolated schema; no cross-tenant data is loaded
            without an explicit selection.
          </Typography>
          <Button
            variant="outlined"
            endIcon={<ArrowOutwardRoundedIcon />}
            href="/dashboard/customers"
          >
            Manage customers
          </Button>
        </CardContent>
      </Card>
    </Box>
  );
}

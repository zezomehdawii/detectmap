'use client';

import { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  AppBar,
  Avatar,
  Box,
  Breadcrumbs,
  Button,
  CircularProgress,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  ListSubheader,
  Menu,
  MenuItem,
  Stack,
  Toolbar,
  Tooltip,
  Typography,
} from '@mui/material';
import GridViewRoundedIcon from '@mui/icons-material/GridViewRounded';
import GridOnRoundedIcon from '@mui/icons-material/GridOnRounded';
import GroupsRoundedIcon from '@mui/icons-material/GroupsRounded';
import ReportProblemRoundedIcon from '@mui/icons-material/ReportProblemRounded';
import ShieldRoundedIcon from '@mui/icons-material/ShieldRounded';
import RuleRoundedIcon from '@mui/icons-material/RuleRounded';
import LibraryBooksRoundedIcon from '@mui/icons-material/LibraryBooksRounded';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import HubRoundedIcon from '@mui/icons-material/HubRounded';
import BusinessCenterRoundedIcon from '@mui/icons-material/BusinessCenterRounded';
import StorefrontRoundedIcon from '@mui/icons-material/StorefrontRounded';
import SettingsRoundedIcon from '@mui/icons-material/SettingsRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import SwapHorizRoundedIcon from '@mui/icons-material/SwapHorizRounded';

import {
  clearToken,
  getActiveCustomer,
  getToken,
  setActiveCustomer,
} from '@/lib/auth';
import {
  CustomerOut,
  MeResponse,
  fetchMe,
  listCustomers,
} from '@/lib/api';
import { gradients } from '../theme';

const DRAWER_WIDTH = 248;

type NavItem = { label: string; href: string; icon: React.ReactNode };
type NavGroup = { heading: string; items: NavItem[] };

const NAV: NavGroup[] = [
  {
    heading: 'Operate',
    items: [
      { label: 'Dashboard', href: '/dashboard', icon: <GridViewRoundedIcon fontSize="small" /> },
      { label: 'Coverage Matrix', href: '/coverage', icon: <GridOnRoundedIcon fontSize="small" /> },
      { label: 'APT Coverage', href: '/apt', icon: <GroupsRoundedIcon fontSize="small" /> },
      { label: 'Gap Analysis', href: '/gaps', icon: <ReportProblemRoundedIcon fontSize="small" /> },
      { label: 'Posture', href: '/posture', icon: <ShieldRoundedIcon fontSize="small" /> },
    ],
  },
  {
    heading: 'Engineer',
    items: [
      { label: 'Detection Library', href: '/detections', icon: <LibraryBooksRoundedIcon fontSize="small" /> },
      { label: 'GRC Crosswalk', href: '/grc', icon: <RuleRoundedIcon fontSize="small" /> },
      { label: 'Reports & Export', href: '/reports', icon: <DownloadRoundedIcon fontSize="small" /> },
      { label: 'Connectors', href: '/connectors', icon: <HubRoundedIcon fontSize="small" /> },
    ],
  },
  {
    heading: 'MSSP',
    items: [
      { label: 'Portfolio', href: '/portfolio', icon: <BusinessCenterRoundedIcon fontSize="small" /> },
      { label: 'Customers', href: '/customers', icon: <StorefrontRoundedIcon fontSize="small" /> },
      { label: 'Settings', href: '/settings', icon: <SettingsRoundedIcon fontSize="small" /> },
    ],
  },
];

function crumbsFor(pathname: string): string[] {
  const segments = pathname.split('/').filter(Boolean);
  return segments.map((s) => s.replace(/-/g, ' '));
}

export default function AuthedLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();

  const [me, setMe] = useState<MeResponse | null>(null);
  const [customers, setCustomers] = useState<CustomerOut[]>([]);
  const [activeCodename, setActive] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [custMenuAnchor, setCustMenuAnchor] = useState<HTMLElement | null>(null);
  const [userMenuAnchor, setUserMenuAnchor] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (!getToken()) {
      router.replace('/login');
      return;
    }
    setActive(getActiveCustomer());
    (async () => {
      try {
        const meRes = await fetchMe();
        setMe(meRes);
        const isMssp = meRes.role.startsWith('mssp_');
        if (isMssp) {
          const list = await listCustomers();
          setCustomers(list);
        } else if (meRes.customer_codename) {
          setActive(meRes.customer_codename);
          setActiveCustomer(meRes.customer_codename);
        }
      } catch {
        clearToken();
        router.replace('/login');
      } finally {
        setLoading(false);
      }
    })();
  }, [router]);

  function handleLogout() {
    clearToken();
    router.replace('/login');
  }

  function handleSwitchCustomer(codename: string) {
    setActiveCustomer(codename);
    setActive(codename);
    setCustMenuAnchor(null);
    // Refresh current screen so it re-queries with the new tenant header.
    router.refresh();
  }

  if (loading) {
    return (
      <Box sx={{ minHeight: '100vh', display: 'grid', placeItems: 'center' }}>
        <CircularProgress />
      </Box>
    );
  }

  const isMssp = me?.role.startsWith('mssp_') ?? false;
  const activeCustomerName =
    customers.find((c) => c.codename === activeCodename)?.name ??
    me?.customer_name ??
    null;

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh', bgcolor: 'background.default' }}>
      <Drawer
        variant="permanent"
        sx={{
          width: DRAWER_WIDTH,
          flexShrink: 0,
          [`& .MuiDrawer-paper`]: { width: DRAWER_WIDTH, boxSizing: 'border-box' },
        }}
      >
        <Toolbar sx={{ px: 3 }}>
          <Typography
            variant="h6"
            sx={{
              background: gradients.cta,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontWeight: 800,
              letterSpacing: '-0.02em',
            }}
          >
            Detection Map
          </Typography>
        </Toolbar>
        <Divider sx={{ mx: 2 }} />
        <Box sx={{ overflowY: 'auto', flex: 1, py: 1 }}>
          {NAV.map((group) => (
            <List
              key={group.heading}
              dense
              subheader={
                <ListSubheader
                  disableSticky
                  sx={{
                    bgcolor: 'transparent',
                    color: 'text.secondary',
                    fontSize: '0.7rem',
                    fontWeight: 700,
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    pl: 3,
                  }}
                >
                  {group.heading}
                </ListSubheader>
              }
            >
              {group.items.map((item) => {
                const selected =
                  pathname === item.href || pathname.startsWith(item.href + '/');
                return (
                  <ListItemButton
                    key={item.href}
                    component={Link}
                    href={item.href}
                    selected={selected}
                  >
                    <ListItemIcon sx={{ minWidth: 32, color: 'text.secondary' }}>
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={item.label}
                      primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: 500 }}
                    />
                  </ListItemButton>
                );
              })}
            </List>
          ))}
        </Box>
      </Drawer>

      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <AppBar position="sticky" elevation={0}>
          <Toolbar sx={{ gap: 2 }}>
            <Breadcrumbs sx={{ flex: 1, fontSize: '0.875rem', textTransform: 'capitalize' }}>
              {crumbsFor(pathname).map((c, i, arr) => (
                <Typography
                  key={i}
                  color={i === arr.length - 1 ? 'text.primary' : 'text.secondary'}
                  sx={{ fontWeight: i === arr.length - 1 ? 600 : 400 }}
                >
                  {c}
                </Typography>
              ))}
            </Breadcrumbs>

            {isMssp && (
              <>
                <Tooltip title="Switch active customer">
                  <Button
                    size="small"
                    variant="outlined"
                    startIcon={<SwapHorizRoundedIcon fontSize="small" />}
                    onClick={(e) => setCustMenuAnchor(e.currentTarget)}
                    sx={{ textTransform: 'none' }}
                  >
                    {activeCustomerName ?? 'Select a customer'}
                  </Button>
                </Tooltip>
                <Menu
                  anchorEl={custMenuAnchor}
                  open={Boolean(custMenuAnchor)}
                  onClose={() => setCustMenuAnchor(null)}
                >
                  {customers.length === 0 && (
                    <MenuItem disabled>No customers yet</MenuItem>
                  )}
                  {customers.map((c) => (
                    <MenuItem
                      key={c.codename}
                      selected={c.codename === activeCodename}
                      onClick={() => handleSwitchCustomer(c.codename)}
                    >
                      <Stack>
                        <Typography variant="body2" fontWeight={600}>
                          {c.name}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {c.codename} · {c.sector ?? 'no sector'}
                        </Typography>
                      </Stack>
                    </MenuItem>
                  ))}
                </Menu>
              </>
            )}

            <IconButton onClick={(e) => setUserMenuAnchor(e.currentTarget)} size="small">
              <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main', fontSize: '0.875rem' }}>
                {me?.email?.slice(0, 1).toUpperCase()}
              </Avatar>
            </IconButton>
            <Menu
              anchorEl={userMenuAnchor}
              open={Boolean(userMenuAnchor)}
              onClose={() => setUserMenuAnchor(null)}
            >
              <MenuItem disabled>
                <Stack>
                  <Typography variant="body2" fontWeight={600}>
                    {me?.email}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {me?.role}
                  </Typography>
                </Stack>
              </MenuItem>
              <Divider />
              <MenuItem onClick={handleLogout}>
                <ListItemIcon><LogoutRoundedIcon fontSize="small" /></ListItemIcon>
                Sign out
              </MenuItem>
            </Menu>
          </Toolbar>
        </AppBar>

        <Box component="main" sx={{ flex: 1, p: { xs: 2, md: 4 } }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
}

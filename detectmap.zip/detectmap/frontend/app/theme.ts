'use client';

import { createTheme, alpha } from '@mui/material/styles';

// Detection Map design tokens.
//
// Palette: indigo as the primary, violet for accent gradients on CTAs.
// Coverage cell colors are surfaced as semantic tokens so the matrix and
// legend reference one source of truth.

export const coverage = {
  red: '#e23a3a',     // gap
  amber: '#f0a830',   // partial
  green: '#2fb673',   // strong
  blue: '#5780e8',    // N/A
  grey: '#b8b8c2',    // out of scope
} as const;

export const gradients = {
  cta: 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)',
  ctaHover: 'linear-gradient(135deg, #4338ca 0%, #6d28d9 100%)',
} as const;

const theme = createTheme({
  cssVariables: true,
  palette: {
    mode: 'light',
    primary:   { main: '#4f46e5', dark: '#4338ca', light: '#818cf8', contrastText: '#fff' },
    secondary: { main: '#7c3aed', dark: '#6d28d9', light: '#a78bfa', contrastText: '#fff' },
    background: {
      default: '#f7f8fb',
      paper:   '#ffffff',
    },
    text: {
      primary:   '#16151c',
      secondary: '#5a5868',
    },
    divider: alpha('#16151c', 0.08),
    error:   { main: coverage.red },
    warning: { main: coverage.amber },
    success: { main: coverage.green },
    info:    { main: coverage.blue },
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily:
      "'Manrope', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    h1: { fontWeight: 700, letterSpacing: '-0.02em' },
    h2: { fontWeight: 700, letterSpacing: '-0.02em' },
    h3: { fontWeight: 700, letterSpacing: '-0.015em' },
    h4: { fontWeight: 700, letterSpacing: '-0.01em' },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    button: { fontWeight: 600, textTransform: 'none', letterSpacing: 0 },
    body1: { fontSize: '0.9375rem' },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          fontFeatureSettings: '"cv11", "ss01"',
        },
        code: {
          fontFamily:
            "'JetBrains Mono', ui-monospace, 'SF Mono', Menlo, monospace",
          fontSize: '0.875em',
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 16,
          border: `1px solid ${alpha('#16151c', 0.06)}`,
          boxShadow:
            '0 1px 2px rgba(20, 18, 35, 0.04), 0 4px 16px rgba(20, 18, 35, 0.03)',
        },
      },
    },
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: { borderRadius: 10, paddingInline: 18, paddingBlock: 9 },
        containedPrimary: {
          background: gradients.cta,
          '&:hover': { background: gradients.ctaHover },
        },
      },
    },
    MuiTextField: {
      defaultProps: { size: 'small', variant: 'outlined' },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          backgroundColor: '#fff',
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: '#ffffff',
          color: '#16151c',
          boxShadow: 'none',
          borderBottom: `1px solid ${alpha('#16151c', 0.06)}`,
        },
      },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: '#ffffff',
          borderRight: `1px solid ${alpha('#16151c', 0.06)}`,
        },
      },
    },
    MuiListItemButton: {
      styleOverrides: {
        root: {
          borderRadius: 10,
          marginInline: 8,
          marginBlock: 2,
          '&.Mui-selected': {
            backgroundColor: alpha('#4f46e5', 0.08),
            color: '#4f46e5',
            '& .MuiListItemIcon-root': { color: '#4f46e5' },
            '&:hover': { backgroundColor: alpha('#4f46e5', 0.12) },
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: { root: { borderRadius: 8, fontWeight: 600 } },
    },
  },
});

export default theme;

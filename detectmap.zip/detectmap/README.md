# detectmap

Multi-tenant MSSP platform for **MITRE ATT&CK-driven detection coverage**, gap
analysis, and threat-informed defense.

> **Status — Phase 1 (Foundation) complete.** This drop ships the multi-tenant
> plumbing, auth, RBAC, customer provisioning, migrations (two Alembic trees),
> Docker Compose stack, and the Next.js UI shell with the indigo design
> system. The functional surface (ATT&CK catalog, detections, coverage matrix,
> reports, GRC) lands in subsequent phases — see the roadmap below.

---

## Architecture in one screen

| Layer | What it is |
|---|---|
| **Tenancy** | MSSP org owns N customers; each customer is a Postgres **schema** `cust_<codename>`. Tenant resolves per request via JWT (customer users) or `X-Customer` header (MSSP users). `search_path` is set in a request-scoped transaction and reset on exit. |
| **Auth** | Two JWT audiences with **separate signing secrets**: `tenant` (regular users) and `superadmin` (product super admin). A tenant token cryptographically cannot be used as a super-admin token. |
| **RBAC** | Five roles: `product_super_admin`, `mssp_admin`, `mssp_analyst`, `mssp_readonly`, `customer_user`. Permission grants live in `app/core/rbac.py`. |
| **Backend** | FastAPI · SQLAlchemy 2.0 async · Pydantic v2 · Alembic (two trees: `public` + `customer`) · Postgres 15 · Redis 7 · Celery 5 · Fernet for connector secrets · pySigma (Splunk SPL / Elastic Lucene / Sentinel KQL backends). |
| **Frontend** | Next.js 14 App Router · MUI v6 with `cssVariables` · Manrope (UI) + JetBrains Mono (technique IDs). Light indigo SaaS theme: white sidebar with grouped icon nav, breadcrumb topbar, soft-rounded cards, indigo→violet gradient CTAs. |
| **Deploy** | Docker Compose: `db`, `redis`, `backend`, `worker`, `frontend`. |

---

## Quickstart

### 1. Configure secrets

```bash
cp .env.example .env
```

Generate three secrets and paste into `.env`:

```bash
# Fernet key for encrypting connector credentials at rest
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

# JWT signing secrets — KEEP THESE DIFFERENT
python -c "import secrets; print(secrets.token_urlsafe(64))"   # JWT_TENANT_SECRET
python -c "import secrets; print(secrets.token_urlsafe(64))"   # JWT_SUPERADMIN_SECRET

# Internal API key for bootstrap endpoints
python -c "import secrets; print(secrets.token_urlsafe(32))"   # INTERNAL_API_KEY
```

> The two JWT secrets are deliberately separate. Token forgery against the
> tenant API does **not** grant catalog-management privileges.

### 2. Bring up the stack

```bash
docker compose up --build
```

On first start the backend container automatically runs
`alembic -n public upgrade head` to create the shared public schema
(orgs, customers, users, super admins, ATT&CK catalog tables).

### 3. Bootstrap an MSSP and its first admin

```bash
docker compose exec backend python -m app.scripts.bootstrap \
  --mssp-name "Demo MSSP" \
  --admin-email admin@demo.local --admin-password change-me \
  --super-email super@demo.local --super-password change-me
```

The script is idempotent — safe to re-run.

### 4. Log in

Open **http://localhost:3000** → log in as `admin@demo.local`.
Backend API: **http://localhost:8000** (Swagger at `/docs`).

### 5. Provision a customer

`POST /customers` (or via the UI in Phase 8) with `{"codename": "acme",
"name": "Acme Corp"}`. The provisioning service:

1. Validates the codename against `^[a-z][a-z0-9_]{1,30}$`.
2. `CREATE SCHEMA IF NOT EXISTS cust_acme`.
3. Runs `alembic -n customer upgrade head` against that schema.
4. (Stub) Seeds the default catalog — wired in Phase 3.

Then in the UI top bar the customer switcher shows `acme` for MSSP users.
All subsequent calls send `X-Customer: acme` automatically.

---

## How tenancy actually works

Three pieces conspire:

1. **`app/db/tenant.py`** — a `ContextVar` holds the active schema for the
   current async task.
2. **`tenant_session()`** — opens a transaction and runs
   `SET LOCAL search_path TO "cust_<codename>", public`. Because it's
   `LOCAL`, the setting resets when the connection returns to the pool —
   no leakage between requests sharing connections.
3. **`migrations/customer/env.py`** — reads `DETECTMAP_TARGET_SCHEMA` from
   the environment, sets `search_path`, and tracks Alembic versions in
   `<schema>.alembic_version_customer`. Each tenant's migration head is
   independent.

The middleware in `main.py` calls `set_tenant(None)` in a `finally` to be
defensive against any path that forgets to clear context.

### Resolving the tenant per request

| Role | Resolution |
|---|---|
| `customer_user` | Pinned to `user.customer_id` from the JWT. `X-Customer` header is ignored unless it matches; no cross-tenant access possible. |
| `mssp_*` | Reads `X-Customer` header, verifies the customer belongs to the user's `mssp_org_id`, then sets tenant context. |
| `product_super_admin` | Different audience; operates against `public` schema endpoints (catalog management, MSSP CRUD). No customer tenancy. |

---

## Running tests

```bash
docker compose exec backend pytest -q
```

The current suite covers:

- Schema name validation (rejects injection, uppercase, leading digit, hyphens, dots, empty, too long).
- Password round-trip + unique salts.
- **JWT audience separation** — a `tenant` token is cryptographically
  rejected when checked against the `superadmin` audience and vice
  versa.
- RBAC matrix (super admin can't edit detections; readonly can't write;
  customer user can't see portfolio; analyst writes but doesn't delete).

---

## Roadmap

| Phase | Scope | Status |
|---|---|---|
| **1** | Foundation: tenancy, auth, RBAC, migrations, Docker, UI shell | ✅ this drop |
| 2 | MITRE ATT&CK STIX ingest (Enterprise + ICS + Mobile) + D3FEND + mitigations; scheduled refresh with version-diff notifications | next |
| 3 | Detection catalog: SigmaHQ public ruleset sync; copy-to-customer on provisioning; auto-map `attack.tXXXX` tags → techniques; CRUD; Sigma YAML import/export; "edit a global flips to customized" |   |
| 4 | Coverage matrix: full / sector / APT denominators; DeTT&CT A-B × A-D scoring + posture grade; Navigator-style UI with right side pane |   |
| 5 | APT Coverage screen, Gap Analysis, Posture |   |
| 6 | Reports & exports: JSON / CSV / XLSX / branded executive PDF / ATT&CK Navigator layer JSON / Sigma rule pack / pySigma → SPL / Lucene / KQL |   |
| 7 | GRC crosswalk: NIST CSF, ISO 27001, NCA ECC + compliance-evidence exports |   |
| 8 | Portfolio (MSSP roll-up), Connectors CRUD (Splunk / Sentinel / Elastic with Fernet-encrypted secrets, Test endpoint), Settings, ATT&CK release diff notifications |   |

Live SIEM/EDR sync and Playwright UI E2E tests remain explicit future work.

---

## Project layout

```
detectmap/
├── docker-compose.yml          # db · redis · backend · worker · frontend
├── .env.example
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── alembic.ini             # two named sections: [public], [customer]
│   ├── migrations/
│   │   ├── public/             # shared catalog, orgs, users, super admins
│   │   └── customer/           # per-tenant detections + coverage snapshots
│   ├── app/
│   │   ├── config.py
│   │   ├── main.py             # FastAPI app + middleware
│   │   ├── worker.py           # Celery
│   │   ├── db/
│   │   │   ├── base.py         # async engine, two MetaData objects
│   │   │   └── tenant.py       # ContextVar + tenant_session()
│   │   ├── models/
│   │   │   ├── public.py       # MSSPOrg, Customer, User, SuperAdmin, AttackTechnique
│   │   │   └── customer.py     # Detection (Sigma+overlay), DetectionTechnique, CoverageSnapshot
│   │   ├── core/
│   │   │   ├── security.py     # bcrypt + dual-secret JWT
│   │   │   ├── crypto.py       # Fernet wrapper
│   │   │   └── rbac.py         # Role → Permission grants
│   │   ├── api/
│   │   │   ├── deps.py         # current_tenant_user / require_perm / X-Customer resolution
│   │   │   ├── auth.py
│   │   │   └── customers.py    # provision + list
│   │   ├── services/
│   │   │   └── provisioning.py # CREATE SCHEMA + alembic upgrade + seed
│   │   └── scripts/
│   │       └── bootstrap.py    # CLI: seed MSSP + admin + super admin
│   └── tests/
│       └── test_security.py
└── frontend/
    ├── Dockerfile
    ├── package.json
    ├── next.config.js
    ├── tsconfig.json
    ├── app/
    │   ├── theme.ts            # indigo MUI v6 theme + coverage tokens
    │   ├── layout.tsx
    │   ├── providers.tsx
    │   ├── login/page.tsx
    │   └── dashboard/
    │       ├── layout.tsx      # sidebar + topbar + customer switcher
    │       └── page.tsx        # posture hero + breakdown + top gaps
    └── lib/
        ├── auth.ts
        └── api.ts              # axios instance, attaches Authorization + X-Customer
```

---

## Security notes you should not skip

- **Bcrypt directly**, no passlib double-handling. Cost factor at default 12.
- Tokens are stored in `localStorage` for development convenience. Migrate
  to HttpOnly cookies before going to production — already noted in
  `frontend/lib/auth.ts`.
- The provisioning endpoint runs Alembic via subprocess so the async
  engine never blocks on Alembic's synchronous run-time. The subprocess
  receives `DETECTMAP_TARGET_SCHEMA` in its environment.
- All connector secrets in Phase 8 will be encrypted with the Fernet key
  in `app/core/crypto.py`. Rotate by re-encrypting under the new key;
  do **not** rotate without re-encrypting.

---

## Next step

Run the stack, bootstrap, log in. When you're ready, the next implementation
unit is **Phase 2 — MITRE ATT&CK catalog ingest**.

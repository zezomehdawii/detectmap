"""Async SQLAlchemy engine + session factories + declarative bases.

We keep two MetaData objects:
  - public_metadata: shared cross-tenant tables (mssp_orgs, customers, users, roles)
  - customer_metadata: per-tenant tables created inside each cust_<codename> schema

Two Alembic environments (migrations/public, migrations/customer) target each
metadata. The customer tree is applied once per customer schema at provisioning
time (and again on later upgrades by iterating all customer schemas).
"""
from __future__ import annotations

from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.config import settings

# ---- Engine ---------------------------------------------------------------
engine = create_async_engine(
    settings.database_url,
    echo=settings.app_debug,
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
)

AsyncSessionLocal: async_sessionmaker[AsyncSession] = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)

# ---- Metadata trees -------------------------------------------------------
# Public schema metadata — explicit schema='public' so Alembic generates DDL
# that's unambiguous when search_path is set to a customer schema.
public_metadata = MetaData(schema="public")

# Customer (per-tenant) metadata — NO schema set; tables resolve against
# whatever search_path is active for the connection. The customer Alembic
# env applies these against each cust_<codename> schema.
customer_metadata = MetaData()


class PublicBase(DeclarativeBase):
    metadata = public_metadata


class CustomerBase(DeclarativeBase):
    metadata = customer_metadata

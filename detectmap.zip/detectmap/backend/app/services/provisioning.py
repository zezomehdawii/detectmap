"""Customer provisioning.

Steps:
  1. CREATE SCHEMA cust_<codename> IF NOT EXISTS
  2. Run the customer Alembic migration tree against that schema
  3. Copy the default (SigmaHQ-derived) detection catalog into it

For v1 step 3 is a placeholder hook — the SigmaHQ sync service will be added
in phase 3 and called from here.

Why subprocess for Alembic? Alembic's offline/programmatic API is awkward
with async engines and two trees. Subprocess gives us a clean, deterministic
boundary, the same way operators would run migrations by hand.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shlex
from pathlib import Path

from sqlalchemy import text

from app.config import settings
from app.db.base import engine
from app.db.tenant import schema_for

log = logging.getLogger(__name__)

BACKEND_ROOT = Path(__file__).resolve().parents[2]


async def _create_schema_if_missing(schema: str) -> None:
    async with engine.begin() as conn:
        # schema is validated by schema_for(); inline is safe.
        await conn.execute(text(f'CREATE SCHEMA IF NOT EXISTS "{schema}"'))


async def _run_customer_migrations(schema: str) -> None:
    """Apply the customer Alembic tree to a specific schema.

    We pass the target schema via an env var that the customer env.py reads
    (DETECTMAP_TARGET_SCHEMA) to set version_table_schema and search_path.
    """
    env = os.environ.copy()
    env["DETECTMAP_TARGET_SCHEMA"] = schema

    cmd = "alembic -n customer upgrade head"
    log.info("running customer migrations for schema=%s", schema)
    proc = await asyncio.create_subprocess_exec(
        *shlex.split(cmd),
        cwd=str(BACKEND_ROOT),
        env=env,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(
            f"customer migrations failed for {schema}: "
            f"{stderr.decode(errors='replace')}"
        )
    log.debug("customer migrations ok: %s", stdout.decode(errors="replace"))


async def _seed_default_catalog(schema: str) -> None:
    """Copy the default detection catalog into the new customer schema.

    Phase 3 will replace this stub with a real copy from the public-schema
    'default_detections' table that the SigmaHQ sync populates.
    """
    log.info("seeding default catalog for schema=%s (stub)", schema)
    # Intentionally empty for v1 — wire SigmaHQ sync first.


async def provision_customer(codename: str) -> None:
    """End-to-end provisioning. Idempotent."""
    schema = schema_for(codename)
    await _create_schema_if_missing(schema)
    await _run_customer_migrations(schema)
    await _seed_default_catalog(schema)
    log.info("provisioned customer: %s -> %s", codename, schema)

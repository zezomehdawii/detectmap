"""Celery worker entrypoint.

Tasks land in app.tasks.* (added in later phases — SigmaHQ sync, ATT&CK STIX
refresh, scheduled snapshot generation, async report renders).
"""
from __future__ import annotations

from celery import Celery

from app.config import settings

celery_app = Celery(
    "detectmap",
    broker=settings.celery_broker_url,
    backend=settings.celery_result_backend,
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
)


@celery_app.task(name="detectmap.healthcheck")
def healthcheck() -> str:
    return "ok"

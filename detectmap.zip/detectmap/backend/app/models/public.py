"""Public-schema (cross-tenant) models.

These live in the 'public' schema and are accessible regardless of which
customer schema is on search_path because public_metadata is bound to
schema='public' explicitly.
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import PublicBase


class Role(str, enum.Enum):
    PRODUCT_SUPER_ADMIN = "product_super_admin"
    MSSP_ADMIN = "mssp_admin"
    MSSP_ANALYST = "mssp_analyst"
    MSSP_READONLY = "mssp_readonly"
    CUSTOMER_USER = "customer_user"


class CustomerStatus(str, enum.Enum):
    PROVISIONING = "provisioning"
    ACTIVE = "active"
    SUSPENDED = "suspended"
    ARCHIVED = "archived"


def _uuid_pk() -> Mapped[uuid.UUID]:
    return mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )


class MSSPOrg(PublicBase):
    __tablename__ = "mssp_orgs"

    id: Mapped[uuid.UUID] = _uuid_pk()
    name: Mapped[str] = mapped_column(String(200), nullable=False, unique=True)
    branding: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    customers: Mapped[list["Customer"]] = relationship(back_populates="mssp_org")
    users: Mapped[list["User"]] = relationship(back_populates="mssp_org")


class Customer(PublicBase):
    __tablename__ = "customers"
    __table_args__ = (
        UniqueConstraint("mssp_org_id", "codename", name="uq_customer_org_codename"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    mssp_org_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.mssp_orgs.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    codename: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    sector: Mapped[Optional[str]] = mapped_column(String(80))
    status: Mapped[CustomerStatus] = mapped_column(
        SAEnum(CustomerStatus, name="customer_status"),
        default=CustomerStatus.PROVISIONING,
        nullable=False,
    )
    branding: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    mssp_org: Mapped[MSSPOrg] = relationship(back_populates="customers")
    users: Mapped[list["User"]] = relationship(back_populates="customer")

    @property
    def schema_name(self) -> str:
        return f"cust_{self.codename}"


class User(PublicBase):
    """Tenant users — MSSP staff and customer users.

    Constraints (enforced in service layer + check constraint):
      - MSSP roles (mssp_*) must have mssp_org_id set and customer_id NULL.
      - CUSTOMER_USER must have customer_id set; mssp_org_id is the parent MSSP.
      - PRODUCT_SUPER_ADMIN does not live here — see SuperAdmin model.
    """
    __tablename__ = "users"
    __table_args__ = (
        UniqueConstraint("email", name="uq_users_email"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    email: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[Optional[str]] = mapped_column(String(200))
    role: Mapped[Role] = mapped_column(SAEnum(Role, name="user_role"), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    mssp_org_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.mssp_orgs.id", ondelete="CASCADE"),
        index=True,
    )
    customer_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("public.customers.id", ondelete="CASCADE"),
        index=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    mssp_org: Mapped[Optional[MSSPOrg]] = relationship(back_populates="users")
    customer: Mapped[Optional[Customer]] = relationship(back_populates="users")


class SuperAdmin(PublicBase):
    """Product Super Admin — manages the global catalog, MITRE, MSSPs.

    Separate table + separate JWT signing key isolates this blast radius
    from tenant auth: a leaked tenant JWT secret cannot mint super-admin tokens.
    """
    __tablename__ = "super_admins"

    id: Mapped[uuid.UUID] = _uuid_pk()
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[Optional[str]] = mapped_column(String(200))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )


class AttackCatalogVersion(PublicBase):
    """Tracks ingested ATT&CK STIX bundle versions across domains."""
    __tablename__ = "attack_catalog_versions"
    __table_args__ = (
        UniqueConstraint("domain", "version", name="uq_attack_domain_version"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    domain: Mapped[str] = mapped_column(String(20), nullable=False)  # enterprise/ics/mobile
    version: Mapped[str] = mapped_column(String(20), nullable=False)
    ingested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    summary: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    is_current: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)


class AttackTechnique(PublicBase):
    """Flattened ATT&CK technique catalog — synced from STIX, shared across tenants."""
    __tablename__ = "attack_techniques"
    __table_args__ = (
        UniqueConstraint("domain", "technique_id", name="uq_attack_domain_tid"),
    )

    id: Mapped[uuid.UUID] = _uuid_pk()
    domain: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    technique_id: Mapped[str] = mapped_column(String(20), nullable=False, index=True)  # e.g. T1059.001
    parent_technique_id: Mapped[Optional[str]] = mapped_column(String(20), index=True)
    name: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    tactics: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    platforms: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    data_sources: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    is_subtechnique: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    deprecated: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    raw_stix: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)

"""Per-tenant (customer-schema) models.

Bound to CustomerBase / customer_metadata which carry no schema qualifier.
At query time these tables resolve against whatever schema search_path
points to (cust_<codename>), which is set per request by tenant_session().
"""
from __future__ import annotations

import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Enum as SAEnum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import CustomerBase


class DetectionStatus(str, enum.Enum):
    IDEA = "idea"
    IN_DEVELOPMENT = "in_development"
    TUNING = "tuning"
    DEPLOYED = "deployed"
    GAP = "gap"
    NOT_APPLICABLE = "not_applicable"


class DetectionSource(str, enum.Enum):
    GLOBAL = "global"          # synced from SigmaHQ catalog, untouched
    CUSTOMIZED = "customized"  # SigmaHQ rule that the customer has edited
    CUSTOM = "custom"          # customer-authored from scratch


class SigmaLevel(str, enum.Enum):
    INFORMATIONAL = "informational"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class Detection(CustomerBase):
    """A Sigma rule + operational overlay (status, scoring, source provenance).

    The 'sigma_*' columns mirror the Sigma spec 1:1 so a rule can round-trip
    to/from YAML without lossy transformation. Operational columns (status,
    breadth/depth scores, source) sit alongside but never serialize into the
    exported YAML.
    """
    __tablename__ = "detections"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    # --- Sigma spec fields ---
    sigma_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(500), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    sigma_status: Mapped[Optional[str]] = mapped_column(String(32))  # stable/test/experimental/deprecated
    level: Mapped[Optional[SigmaLevel]] = mapped_column(SAEnum(SigmaLevel, name="sigma_level"))
    author: Mapped[Optional[str]] = mapped_column(String(200))
    sigma_references: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    tags: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    logsource: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    detection: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    falsepositives: Mapped[list] = mapped_column(JSONB, default=list, nullable=False)
    raw_yaml: Mapped[Optional[str]] = mapped_column(Text)  # canonical YAML for round-trip

    # --- Operational overlay ---
    detection_status: Mapped[DetectionStatus] = mapped_column(
        SAEnum(DetectionStatus, name="detection_status"),
        default=DetectionStatus.IDEA,
        nullable=False,
        index=True,
    )
    source: Mapped[DetectionSource] = mapped_column(
        SAEnum(DetectionSource, name="detection_source"),
        default=DetectionSource.CUSTOM,
        nullable=False,
        index=True,
    )
    # DeTT&CT-style scoring on a 0-5 integer scale per dimension.
    score_breadth: Mapped[int] = mapped_column(Integer, default=0, nullable=False)  # A-B
    score_depth: Mapped[int] = mapped_column(Integer, default=0, nullable=False)    # A-D

    # Origin tracking for global-rule overrides (lets us reset to upstream).
    upstream_global_id: Mapped[Optional[str]] = mapped_column(String(64), index=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )

    technique_mappings: Mapped[list["DetectionTechnique"]] = relationship(
        back_populates="detection", cascade="all, delete-orphan"
    )


class DetectionTechnique(CustomerBase):
    """Many-to-many: a detection covers one or more ATT&CK techniques.

    technique_id is the bare string (e.g. T1059.001) — we don't FK into the
    public attack_techniques table because customer schemas should be
    self-contained for portability. The catalog is treated as a reference
    universe, not a constraint.
    """
    __tablename__ = "detection_techniques"
    __table_args__ = (
        UniqueConstraint("detection_id", "technique_id", name="uq_det_tech"),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    detection_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("detections.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    technique_id: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    domain: Mapped[str] = mapped_column(String(20), nullable=False, default="enterprise")

    detection: Mapped[Detection] = relationship(back_populates="technique_mappings")


class CoverageSnapshot(CustomerBase):
    """Point-in-time roll-up of coverage posture for audit history & reports."""
    __tablename__ = "coverage_snapshots"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    taken_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    denominator_kind: Mapped[str] = mapped_column(String(20), nullable=False)  # full/sector/apt
    denominator_ref: Mapped[Optional[str]] = mapped_column(String(80))  # e.g. apt29, finance
    breadth_score: Mapped[str] = mapped_column(String(2), nullable=False)  # A..B
    depth_score: Mapped[str] = mapped_column(String(2), nullable=False)    # A..D
    posture_grade: Mapped[str] = mapped_column(String(2), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, default=dict, nullable=False)
    notes: Mapped[Optional[str]] = mapped_column(Text)

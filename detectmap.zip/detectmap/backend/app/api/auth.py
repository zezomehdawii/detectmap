"""Auth endpoints.

POST /auth/login        — MSSP staff + customer users  (JWT signed with tenant secret)
POST /auth/superadmin   — Product Super Admins         (JWT signed with super-admin secret)
GET  /auth/me           — Current tenant principal     (debug / UI bootstrap)
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy import select

from app.api.deps import TenantPrincipal, current_tenant_user
from app.core.security import TokenAudience, create_access_token, verify_password
from app.db.base import AsyncSessionLocal
from app.models.public import SuperAdmin, User

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class MeResponse(BaseModel):
    user_id: str
    email: str
    role: str
    customer_codename: str | None
    customer_name: str | None
    mssp_org_id: str | None


@router.post("/login", response_model=TokenResponse)
async def login(req: LoginRequest) -> TokenResponse:
    async with AsyncSessionLocal() as session:
        user = (
            await session.execute(select(User).where(User.email == req.email))
        ).scalar_one_or_none()
        if user is None or not user.is_active or not verify_password(
            req.password, user.hashed_password
        ):
            raise HTTPException(401, "Invalid credentials")

        user.last_login_at = datetime.now(timezone.utc)
        await session.commit()

        claims = {
            "role": user.role.value,
            "mssp_org_id": str(user.mssp_org_id) if user.mssp_org_id else None,
            "customer_id": str(user.customer_id) if user.customer_id else None,
        }
        token = create_access_token(
            subject=str(user.id),
            audience=TokenAudience.TENANT,
            claims=claims,
        )
        return TokenResponse(access_token=token)


@router.post("/superadmin", response_model=TokenResponse)
async def superadmin_login(req: LoginRequest) -> TokenResponse:
    async with AsyncSessionLocal() as session:
        admin = (
            await session.execute(
                select(SuperAdmin).where(SuperAdmin.email == req.email)
            )
        ).scalar_one_or_none()
        if admin is None or not admin.is_active or not verify_password(
            req.password, admin.hashed_password
        ):
            raise HTTPException(401, "Invalid credentials")
        token = create_access_token(
            subject=str(admin.id),
            audience=TokenAudience.SUPERADMIN,
        )
        return TokenResponse(access_token=token)


@router.get("/me", response_model=MeResponse)
async def me(principal: TenantPrincipal = Depends(current_tenant_user)) -> MeResponse:
    return MeResponse(
        user_id=str(principal.user.id),
        email=principal.user.email,
        role=principal.user.role.value,
        customer_codename=principal.customer.codename if principal.customer else None,
        customer_name=principal.customer.name if principal.customer else None,
        mssp_org_id=(
            str(principal.user.mssp_org_id) if principal.user.mssp_org_id else None
        ),
    )

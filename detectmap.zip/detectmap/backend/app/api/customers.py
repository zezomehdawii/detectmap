"""Customer management endpoints."""
from __future__ import annotations

import uuid
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select

from app.api.deps import (
    TenantPrincipal,
    current_tenant_user,
    require_perm,
)
from app.core.rbac import Permission
from app.db.base import AsyncSessionLocal
from app.db.tenant import schema_for
from app.models.public import Customer, CustomerStatus, Role
from app.services.provisioning import provision_customer

router = APIRouter(prefix="/customers", tags=["customers"])


class CustomerCreate(BaseModel):
    codename: str = Field(min_length=2, max_length=30, pattern=r"^[a-z][a-z0-9_]{1,29}$")
    name: str = Field(min_length=2, max_length=200)
    sector: Optional[str] = None


class CustomerOut(BaseModel):
    id: str
    codename: str
    name: str
    sector: Optional[str]
    status: str
    schema_name: str


def _serialize(c: Customer) -> CustomerOut:
    return CustomerOut(
        id=str(c.id),
        codename=c.codename,
        name=c.name,
        sector=c.sector,
        status=c.status.value,
        schema_name=schema_for(c.codename),
    )


@router.get("", response_model=list[CustomerOut])
async def list_customers(
    principal: TenantPrincipal = Depends(require_perm(Permission.CUSTOMER_READ)),
) -> list[CustomerOut]:
    async with AsyncSessionLocal() as session:
        if principal.user.role == Role.CUSTOMER_USER:
            # A customer user sees only their own customer.
            stmt = select(Customer).where(Customer.id == principal.user.customer_id)
        else:
            stmt = select(Customer).where(
                Customer.mssp_org_id == principal.user.mssp_org_id
            )
        rows = (await session.execute(stmt)).scalars().all()
        return [_serialize(c) for c in rows]


@router.post("", response_model=CustomerOut, status_code=201)
async def create_customer(
    payload: CustomerCreate,
    principal: TenantPrincipal = Depends(require_perm(Permission.CUSTOMER_PROVISION)),
) -> CustomerOut:
    if principal.user.mssp_org_id is None:
        raise HTTPException(400, "Caller has no MSSP org")

    async with AsyncSessionLocal() as session:
        existing = (
            await session.execute(
                select(Customer).where(
                    Customer.mssp_org_id == principal.user.mssp_org_id,
                    Customer.codename == payload.codename,
                )
            )
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(409, "Codename already used in this MSSP")

        customer = Customer(
            id=uuid.uuid4(),
            mssp_org_id=principal.user.mssp_org_id,
            codename=payload.codename,
            name=payload.name,
            sector=payload.sector,
            status=CustomerStatus.PROVISIONING,
        )
        session.add(customer)
        await session.commit()
        await session.refresh(customer)

    # Provisioning is synchronous here for v1; queue this onto Celery once
    # default-catalog copy (~3,300 rules) is wired up.
    await provision_customer(customer.codename)

    async with AsyncSessionLocal() as session:
        customer = (
            await session.execute(select(Customer).where(Customer.id == customer.id))
        ).scalar_one()
        customer.status = CustomerStatus.ACTIVE
        await session.commit()
        await session.refresh(customer)
        return _serialize(customer)


@router.get("/{codename}", response_model=CustomerOut)
async def get_customer(
    codename: str,
    principal: TenantPrincipal = Depends(require_perm(Permission.CUSTOMER_READ)),
) -> CustomerOut:
    async with AsyncSessionLocal() as session:
        stmt = select(Customer).where(Customer.codename == codename)
        if principal.user.role == Role.CUSTOMER_USER:
            stmt = stmt.where(Customer.id == principal.user.customer_id)
        else:
            stmt = stmt.where(Customer.mssp_org_id == principal.user.mssp_org_id)
        customer = (await session.execute(stmt)).scalar_one_or_none()
        if customer is None:
            raise HTTPException(404, "Customer not found")
        return _serialize(customer)

"""Role-based access control matrix.

Permissions are coarse-grained verbs over object types. The matrix below is
the source of truth — endpoints declare a required Permission via
require_perm() dependency rather than hard-coding role checks.
"""
from __future__ import annotations

import enum

from app.models.public import Role


class Permission(str, enum.Enum):
    # Customer-scoped detection ops
    DETECTION_READ = "detection:read"
    DETECTION_WRITE = "detection:write"
    DETECTION_DELETE = "detection:delete"

    # Customer-scoped coverage / reporting
    COVERAGE_READ = "coverage:read"
    REPORT_EXPORT = "report:export"

    # Customer lifecycle (MSSP)
    CUSTOMER_PROVISION = "customer:provision"
    CUSTOMER_READ = "customer:read"
    CUSTOMER_PORTFOLIO = "customer:portfolio"

    # Connector configuration
    CONNECTOR_READ = "connector:read"
    CONNECTOR_WRITE = "connector:write"

    # Product-level admin
    CATALOG_MANAGE = "catalog:manage"  # MITRE / SigmaHQ syncs
    MSSP_MANAGE = "mssp:manage"


# Permission grants by role. Anything not listed = denied.
_GRANTS: dict[Role, set[Permission]] = {
    Role.PRODUCT_SUPER_ADMIN: {
        Permission.CATALOG_MANAGE,
        Permission.MSSP_MANAGE,
        Permission.CUSTOMER_READ,
        Permission.CUSTOMER_PROVISION,
    },
    Role.MSSP_ADMIN: {
        Permission.DETECTION_READ,
        Permission.DETECTION_WRITE,
        Permission.DETECTION_DELETE,
        Permission.COVERAGE_READ,
        Permission.REPORT_EXPORT,
        Permission.CUSTOMER_PROVISION,
        Permission.CUSTOMER_READ,
        Permission.CUSTOMER_PORTFOLIO,
        Permission.CONNECTOR_READ,
        Permission.CONNECTOR_WRITE,
    },
    Role.MSSP_ANALYST: {
        Permission.DETECTION_READ,
        Permission.DETECTION_WRITE,
        Permission.COVERAGE_READ,
        Permission.REPORT_EXPORT,
        Permission.CUSTOMER_READ,
        Permission.CUSTOMER_PORTFOLIO,
        Permission.CONNECTOR_READ,
    },
    Role.MSSP_READONLY: {
        Permission.DETECTION_READ,
        Permission.COVERAGE_READ,
        Permission.REPORT_EXPORT,
        Permission.CUSTOMER_READ,
        Permission.CUSTOMER_PORTFOLIO,
        Permission.CONNECTOR_READ,
    },
    Role.CUSTOMER_USER: {
        # Customer users have full read+edit of THEIR OWN tenant data.
        # Tenant isolation is enforced separately via schema scoping +
        # customer_id pin in the JWT.
        Permission.DETECTION_READ,
        Permission.DETECTION_WRITE,
        Permission.DETECTION_DELETE,
        Permission.COVERAGE_READ,
        Permission.REPORT_EXPORT,
        Permission.CONNECTOR_READ,
    },
}


def role_has(role: Role, perm: Permission) -> bool:
    return perm in _GRANTS.get(role, set())


__all__ = ["Permission", "role_has"]
